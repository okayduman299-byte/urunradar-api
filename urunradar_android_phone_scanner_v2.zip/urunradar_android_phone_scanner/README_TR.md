# ÜrünRadar Android Telefon Tarayıcı v2

Bu sürüm Trendyol kategori sayfalarındaki gerçek ürün bağlantılarını telefondaki WebView ile bulur.

Önemli farklar:
- Yalnızca `-p-<ürün id>` biçimindeki gerçek Trendyol ürün adreslerini kabul eder.
- Her ürün sayfasını telefonda açıp JSON-LD/DOM üzerinden ad, fiyat, puan, yorum ve görsel bilgisi okur.
- Genel Trendyol ana sayfası başlıklarını reddeder.
- Veriyi `POST /api/native-watch` ile ÜrünRadar v8 sunucusuna gönderir.
- Eski izlenen ürünleri de tekrar gözlemlemeye çalışır.
- Uygulama açıldığında son taramadan 6 saat geçtiyse otomatik tarama başlatır.

Sunucu gereksinimi: `app-auto-v8.py` veya daha yeni bir sürüm.
