package com.urunradar.app;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final String APP_URL = "https://urunradar-api.onrender.com/mobile?native=2";
    private static final String API_PRODUCTS = "https://urunradar-api.onrender.com/api/products?sort=recent";
    private static final String API_NATIVE_WATCH = "https://urunradar-api.onrender.com/api/native-watch";
    private static final long AUTO_SCAN_INTERVAL_MS = 6L * 60L * 60L * 1000L;

    private static final int PHASE_IDLE = 0;
    private static final int PHASE_DISCOVERY = 1;
    private static final int PHASE_PRODUCT = 2;

    private static final int MAX_KNOWN_PRODUCTS = 5;
    private static final int MAX_NEW_LINKS_PER_CATEGORY = 2;
    private static final int MAX_TOTAL_PRODUCTS_PER_SCAN = 10;

    private static final String MOBILE_CHROME_UA =
        "Mozilla/5.0 (Linux; Android 13; Mobile) " +
        "AppleWebKit/537.36 (KHTML, like Gecko) " +
        "Chrome/126.0 Mobile Safari/537.36";

    private static final class CategorySource {
        final String name;
        final String url;

        CategorySource(String name, String url) {
            this.name = name;
            this.url = url;
        }
    }

    private static final class Candidate {
        final String url;
        final String category;

        Candidate(String url, String category) {
            this.url = url;
            this.category = category;
        }
    }

    private static final List<CategorySource> CATEGORY_SOURCES = Arrays.asList(
        new CategorySource("Airfryer", "https://www.trendyol.com/fritoz-x-c1055?pi=2"),
        new CategorySource("Robot Süpürge", "https://www.trendyol.com/robot-supurge-x-c109453?pi=2"),
        new CategorySource("Bluetooth Kulaklık", "https://www.trendyol.com/bluetooth-kulaklik-x-c108626?pi=2"),
        new CategorySource("Akıllı Saat", "https://www.trendyol.com/akilli-saat-x-c1240?pi=2"),
        new CategorySource("Powerbank", "https://www.trendyol.com/tasinabilir-batarya-x-c103113?pi=2")
    );

    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final ExecutorService networkExecutor = Executors.newSingleThreadExecutor();
    private final Map<String, Candidate> candidates = new LinkedHashMap<>();

    private WebView appWebView;
    private WebView scannerWebView;

    private boolean scanning = false;
    private boolean autoScanChecked = false;
    private int phase = PHASE_IDLE;
    private int categoryIndex = 0;
    private int productIndex = 0;
    private int loadToken = 0;
    private int successCount = 0;
    private int failedCount = 0;
    private List<Candidate> productQueue = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(246, 248, 252));

        scannerWebView = new WebView(this);
        scannerWebView.setAlpha(0.01f);
        scannerWebView.setClickable(false);
        scannerWebView.setFocusable(false);
        configureScannerWebView(scannerWebView);
        root.addView(scannerWebView, new FrameLayout.LayoutParams(1080, 1600));

        appWebView = new WebView(this);
        configureAppWebView(appWebView);
        root.addView(appWebView, new FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        ));

        setContentView(root);
        appWebView.loadUrl(APP_URL);
    }

    private void configureCommonSettings(WebView webView) {
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setLoadsImagesAutomatically(true);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setSupportMultipleWindows(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);
    }

    private void configureAppWebView(WebView webView) {
        configureCommonSettings(webView);
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if ("urunradar".equals(uri.getScheme()) && "scan".equals(uri.getHost())) {
                    startLocalScan(false);
                    return true;
                }
                if ("https".equals(uri.getScheme()) && "urunradar-api.onrender.com".equals(uri.getHost())) {
                    return false;
                }
                startActivity(new Intent(Intent.ACTION_VIEW, uri));
                return true;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                injectLocalScannerButton();
                maybeAutoScanAfterLaunch();
            }
        });
    }

    private void configureScannerWebView(WebView webView) {
        configureCommonSettings(webView);
        webView.getSettings().setUserAgentString(MOBILE_CHROME_UA);
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return false;
            }
        });
    }

    private void injectLocalScannerButton() {
        String script = "(function(){" +
            "const b=document.getElementById('discoverBtn');" +
            "if(!b)return;" +
            "b.textContent='Telefondan Gerçek Ürün Tara';" +
            "b.onclick=function(e){e.preventDefault();location.href='urunradar://scan';return false;};" +
            "})();";
        appWebView.evaluateJavascript(script, null);
    }

    private void maybeAutoScanAfterLaunch() {
        if (autoScanChecked) return;
        autoScanChecked = true;
        SharedPreferences prefs = getSharedPreferences("urunradar", MODE_PRIVATE);
        long lastScan = prefs.getLong("last_scan_ms", 0L);
        if (System.currentTimeMillis() - lastScan >= AUTO_SCAN_INTERVAL_MS) {
            mainHandler.postDelayed(() -> startLocalScan(true), 2500L);
        }
    }

    private void startLocalScan(boolean automatic) {
        if (scanning) {
            Toast.makeText(this, "Tarama zaten çalışıyor.", Toast.LENGTH_SHORT).show();
            return;
        }

        scanning = true;
        phase = PHASE_IDLE;
        categoryIndex = 0;
        productIndex = 0;
        loadToken++;
        successCount = 0;
        failedCount = 0;
        candidates.clear();
        productQueue = new ArrayList<>();

        setScanButtonState("Telefon gerçek ürünleri tarıyor…", true);
        Toast.makeText(
            this,
            automatic ? "Otomatik telefon taraması başladı." : "Telefon taraması başladı.",
            Toast.LENGTH_SHORT
        ).show();

        networkExecutor.execute(() -> {
            List<Candidate> known = fetchKnownProducts();
            mainHandler.post(() -> {
                for (Candidate candidate : known) {
                    addCandidate(candidate);
                }
                beginDiscovery();
            });
        });
    }

    private List<Candidate> fetchKnownProducts() {
        List<Candidate> result = new ArrayList<>();
        HttpURLConnection connection = null;
        try {
            connection = (HttpURLConnection) new URL(API_PRODUCTS).openConnection();
            connection.setRequestMethod("GET");
            connection.setConnectTimeout(15_000);
            connection.setReadTimeout(20_000);
            connection.setRequestProperty("Accept", "application/json");
            int status = connection.getResponseCode();
            if (status < 200 || status >= 300) return result;

            String body = readAll(connection.getInputStream());
            JSONArray array = new JSONArray(body);
            for (int i = 0; i < array.length() && result.size() < MAX_KNOWN_PRODUCTS; i++) {
                JSONObject item = array.optJSONObject(i);
                if (item == null) continue;
                String url = canonicalProductUrl(item.optString("url", ""));
                if (url == null) continue;
                String category = item.optString("category", "Genel");
                result.add(new Candidate(url, category));
            }
        } catch (Exception ignored) {
        } finally {
            if (connection != null) connection.disconnect();
        }
        return result;
    }

    private void beginDiscovery() {
        if (!scanning) return;
        phase = PHASE_DISCOVERY;
        categoryIndex = 0;
        loadNextCategory();
    }

    private void loadNextCategory() {
        if (!scanning || phase != PHASE_DISCOVERY) return;
        if (categoryIndex >= CATEGORY_SOURCES.size() || candidates.size() >= MAX_TOTAL_PRODUCTS_PER_SCAN) {
            beginProductScan();
            return;
        }

        CategorySource source = CATEGORY_SOURCES.get(categoryIndex);
        int token = ++loadToken;
        scannerWebView.loadUrl(source.url);
        mainHandler.postDelayed(() -> extractCategoryLinks(source, false, token), 5500L);
    }

    private void extractCategoryLinks(CategorySource source, boolean afterScroll, int token) {
        if (!scanning || phase != PHASE_DISCOVERY || token != loadToken) return;

        String script = "(function(){" +
            "const out=[];const seen=new Set();" +
            "for(const a of document.querySelectorAll('a[href]')){" +
            "try{const u=new URL(a.getAttribute('href'),location.href);" +
            "const host=u.hostname.replace(/^www\\./,'').toLowerCase();" +
            "if(host!=='trendyol.com'&&host!=='m.trendyol.com')continue;" +
            "if(!/-p-\\d+(?:$|\\/)/i.test(u.pathname))continue;" +
            "const clean='https://www.trendyol.com'+u.pathname.replace(/\\/$/,'');" +
            "if(!seen.has(clean)){seen.add(clean);out.push(clean);}" +
            "}catch(e){}}" +
            "return JSON.stringify(out.slice(0,25));" +
            "})();";

        scannerWebView.evaluateJavascript(script, value -> {
            if (!scanning || phase != PHASE_DISCOVERY || token != loadToken) return;
            List<String> links = decodeJavascriptArray(value);
            int added = 0;
            for (String raw : links) {
                if (candidates.size() >= MAX_TOTAL_PRODUCTS_PER_SCAN) break;
                if (added >= MAX_NEW_LINKS_PER_CATEGORY) break;
                String clean = canonicalProductUrl(raw);
                if (clean == null || candidates.containsKey(clean)) continue;
                addCandidate(new Candidate(clean, source.name));
                added++;
            }

            if (added == 0 && !afterScroll) {
                scannerWebView.evaluateJavascript(
                    "window.scrollTo(0,Math.max(document.body.scrollHeight*0.75,1400));",
                    ignored -> mainHandler.postDelayed(
                        () -> extractCategoryLinks(source, true, token),
                        3500L
                    )
                );
                return;
            }

            categoryIndex++;
            mainHandler.postDelayed(this::loadNextCategory, 700L);
        });
    }

    private void beginProductScan() {
        if (!scanning) return;
        phase = PHASE_PRODUCT;
        productQueue = new ArrayList<>(candidates.values());
        if (productQueue.size() > MAX_TOTAL_PRODUCTS_PER_SCAN) {
            productQueue = new ArrayList<>(productQueue.subList(0, MAX_TOTAL_PRODUCTS_PER_SCAN));
        }
        productIndex = 0;

        if (productQueue.isEmpty()) {
            completeScan("Gerçek ürün bağlantısı bulunamadı.");
            return;
        }
        loadNextProduct();
    }

    private void loadNextProduct() {
        if (!scanning || phase != PHASE_PRODUCT) return;
        if (productIndex >= productQueue.size()) {
            completeScan(
                successCount + " gerçek ürün kaydedildi, " + failedCount + " ürün atlandı."
            );
            return;
        }

        Candidate candidate = productQueue.get(productIndex);
        int token = ++loadToken;
        scannerWebView.loadUrl(candidate.url);
        mainHandler.postDelayed(
            () -> extractProductData(candidate, token, false),
            5200L
        );
    }

    private void extractProductData(Candidate candidate, int token, boolean retried) {
        if (!scanning || phase != PHASE_PRODUCT || token != loadToken) return;

        String script = "(function(){" +
            "function generic(s){s=(s||'').toLowerCase();return !s||" +
            "s.includes('online alışveriş sitesi')||s.includes(\"türkiye'nin trend yolu\")||" +
            "s.includes(\"turkiye'nin trend yolu\")||s.includes('trendyol - online');}" +
            "function validUrl(v){try{const u=new URL(v);const h=u.hostname.replace(/^www\\./,'').toLowerCase();" +
            "return (h==='trendyol.com'||h==='m.trendyol.com')&&/-p-\\d+(?:$|\\/)/i.test(u.pathname);}catch(e){return false;}}" +
            "function num(v){if(v===null||v===undefined||v==='')return null;if(typeof v==='number')return isFinite(v)?v:null;" +
            "let s=String(v).replace(/[^0-9,.-]/g,'');if(!s)return null;" +
            "if(s.includes(',')&&s.includes('.'))s=s.replace(/\\./g,'').replace(',','.');" +
            "else if(s.includes(','))s=s.replace(',','.');else if((s.match(/\\./g)||[]).length>1)s=s.replace(/\\./g,'');" +
            "const n=Number(s);return isFinite(n)?n:null;}" +
            "function walk(v){if(!v)return null;if(Array.isArray(v)){for(const x of v){const r=walk(x);if(r)return r;}return null;}" +
            "if(typeof v==='object'){const t=v['@type'];if(t==='Product'||(Array.isArray(t)&&t.includes('Product')))return v;" +
            "if(Array.isArray(v['@graph'])){const r=walk(v['@graph']);if(r)return r;}for(const k of Object.keys(v)){const r=walk(v[k]);if(r)return r;}}return null;}" +
            "let product=null;for(const s of document.querySelectorAll('script[type=\"application/ld+json\"]')){" +
            "try{product=walk(JSON.parse(s.textContent||''));if(product)break;}catch(e){}}" +
            "let name=product&&product.name?String(product.name).trim():'';" +
            "if(!name||generic(name)){const el=document.querySelector('[data-testid=\"product-title\"],h1.pr-new-br,h1');name=el?(el.textContent||'').trim():'';}" +
            "let offers=product&&product.offers?product.offers:null;if(Array.isArray(offers))offers=offers[0]||null;" +
            "let price=num(offers&&(offers.price||offers.lowPrice));if(price===null){const el=document.querySelector('.prc-dsc,.prc-slg,[data-testid=\"price-current-price\"],.product-price-container');price=num(el&&el.textContent);}" +
            "const agg=product&&product.aggregateRating?product.aggregateRating:null;" +
            "let rating=num(agg&&(agg.ratingValue||agg.rating));" +
            "let review=num(agg&&(agg.reviewCount||agg.ratingCount));if(review!==null)review=Math.round(review);" +
            "let image=product&&product.image?product.image:null;if(Array.isArray(image))image=image[0]||null;" +
            "if(image&&typeof image==='object')image=image.url||image.contentUrl||null;" +
            "if(!image){const m=document.querySelector('meta[property=\"og:image\"]');image=m&&m.content?m.content:null;}" +
            "let availability=offers&&offers.availability?String(offers.availability).split('/').pop():null;" +
            "const current=location.href;const ok=validUrl(current)&&!!name&&!generic(name);" +
            "return JSON.stringify({ok:ok,currentUrl:current,title:document.title||'',name:name,price:price,rating:rating,review_count:review,image_url:image,availability:availability,reason:ok?'':'no_product_data'});" +
            "})();";

        scannerWebView.evaluateJavascript(script, value -> {
            if (!scanning || phase != PHASE_PRODUCT || token != loadToken) return;
            JSONObject data = decodeJavascriptObject(value);
            boolean ok = data != null && data.optBoolean("ok", false);

            if (!ok && !retried) {
                mainHandler.postDelayed(
                    () -> extractProductData(candidate, token, true),
                    3200L
                );
                return;
            }

            if (!ok) {
                failedCount++;
                productIndex++;
                mainHandler.postDelayed(this::loadNextProduct, 400L);
                return;
            }

            JSONObject payload = new JSONObject();
            try {
                payload.put("url", candidate.url);
                payload.put("name", data.optString("name", "").trim());
                payload.put("category", candidate.category);
                putIfPresent(payload, "image_url", data, "image_url");
                putIfPresent(payload, "price", data, "price");
                putIfPresent(payload, "rating", data, "rating");
                putIfPresent(payload, "review_count", data, "review_count");
                putIfPresent(payload, "availability", data, "availability");
            } catch (Exception e) {
                failedCount++;
                productIndex++;
                loadNextProduct();
                return;
            }

            networkExecutor.execute(() -> {
                boolean posted = postNativeProduct(payload);
                mainHandler.post(() -> {
                    if (posted) successCount++; else failedCount++;
                    productIndex++;
                    mainHandler.postDelayed(this::loadNextProduct, 400L);
                });
            });
        });
    }

    private void putIfPresent(JSONObject target, String targetKey, JSONObject source, String sourceKey) {
        if (!source.has(sourceKey) || source.isNull(sourceKey)) return;
        Object value = source.opt(sourceKey);
        if (value == null || JSONObject.NULL.equals(value)) return;
        if (value instanceof String && ((String) value).trim().isEmpty()) return;
        try {
            target.put(targetKey, value);
        } catch (Exception ignored) {
        }
    }

    private boolean postNativeProduct(JSONObject payload) {
        HttpURLConnection connection = null;
        try {
            connection = (HttpURLConnection) new URL(API_NATIVE_WATCH).openConnection();
            connection.setRequestMethod("POST");
            connection.setConnectTimeout(20_000);
            connection.setReadTimeout(30_000);
            connection.setDoOutput(true);
            connection.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            connection.setRequestProperty("Accept", "application/json");

            byte[] bytes = payload.toString().getBytes(StandardCharsets.UTF_8);
            connection.setFixedLengthStreamingMode(bytes.length);
            try (OutputStream out = connection.getOutputStream()) {
                out.write(bytes);
            }

            int status = connection.getResponseCode();
            InputStream stream = status >= 200 && status < 300
                ? connection.getInputStream()
                : connection.getErrorStream();
            if (stream != null) readAll(stream);
            return status >= 200 && status < 300;
        } catch (Exception e) {
            return false;
        } finally {
            if (connection != null) connection.disconnect();
        }
    }

    private void addCandidate(Candidate candidate) {
        if (candidate == null || candidates.size() >= MAX_TOTAL_PRODUCTS_PER_SCAN) return;
        candidates.putIfAbsent(candidate.url, candidate);
    }

    private String canonicalProductUrl(String raw) {
        try {
            Uri uri = Uri.parse(raw);
            String host = uri.getHost();
            String path = uri.getPath();
            if (host == null || path == null) return null;
            host = host.toLowerCase().replaceFirst("^www\\.", "");
            if (!host.equals("trendyol.com") && !host.equals("m.trendyol.com")) return null;
            if (!path.matches(".*-p-\\d+(?:$|/).*")) return null;
            return "https://www.trendyol.com" + path.replaceAll("/$", "");
        } catch (Exception e) {
            return null;
        }
    }

    private List<String> decodeJavascriptArray(String value) {
        List<String> result = new ArrayList<>();
        try {
            Object first = new JSONTokener(value).nextValue();
            String json = first instanceof String ? (String) first : value;
            JSONArray array = new JSONArray(json);
            for (int i = 0; i < array.length(); i++) {
                String item = array.optString(i, "");
                if (!item.isEmpty()) result.add(item);
            }
        } catch (Exception ignored) {
        }
        return result;
    }

    private JSONObject decodeJavascriptObject(String value) {
        try {
            Object first = new JSONTokener(value).nextValue();
            String json = first instanceof String ? (String) first : value;
            return new JSONObject(json);
        } catch (Exception ignored) {
            return null;
        }
    }

    private String readAll(InputStream stream) throws Exception {
        StringBuilder out = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(
            new InputStreamReader(stream, StandardCharsets.UTF_8)
        )) {
            String line;
            while ((line = reader.readLine()) != null) out.append(line);
        }
        return out.toString();
    }

    private void completeScan(String message) {
        scanning = false;
        phase = PHASE_IDLE;
        loadToken++;
        getSharedPreferences("urunradar", MODE_PRIVATE)
            .edit()
            .putLong("last_scan_ms", System.currentTimeMillis())
            .apply();
        setScanButtonState("Telefondan Gerçek Ürün Tara", false);
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
        appWebView.loadUrl(APP_URL + "&refresh=" + System.currentTimeMillis());
    }

    private void setScanButtonState(String text, boolean disabled) {
        String escaped = JSONObject.quote(text);
        String script = "(function(){const b=document.getElementById('discoverBtn');if(b){b.textContent=" +
            escaped + ";b.disabled=" + disabled + ";}})();";
        appWebView.evaluateJavascript(script, null);
    }

    @Override
    public void onBackPressed() {
        if (appWebView.canGoBack()) {
            appWebView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        scanning = false;
        phase = PHASE_IDLE;
        loadToken++;
        networkExecutor.shutdownNow();
        appWebView.destroy();
        scannerWebView.destroy();
        super.onDestroy();
    }
}
